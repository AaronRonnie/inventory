﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnAddItem = new Button();
            btnDelete = new Button();
            btnEditItem = new Button();
            itemsTable = new DataGridView();
            ((System.ComponentModel.ISupportInitialize)itemsTable).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            label1.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.Location = new Point(12, 9);
            label1.Name = "label1";
            label1.Size = new Size(1102, 59);
            label1.TabIndex = 0;
            label1.Text = "List of Items";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            label1.Click += label1_Click;
            // 
            // btnAddItem
            // 
            btnAddItem.Location = new Point(21, 94);
            btnAddItem.Name = "btnAddItem";
            btnAddItem.Size = new Size(114, 33);
            btnAddItem.TabIndex = 1;
            btnAddItem.Text = "Add Item";
            btnAddItem.UseVisualStyleBackColor = true;
            btnAddItem.Click += btnAddItem_Click;
            // 
            // btnDelete
            // 
            btnDelete.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnDelete.Location = new Point(871, 94);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(124, 33);
            btnDelete.TabIndex = 2;
            btnDelete.Text = "Delete Item";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += button1_Click;
            // 
            // btnEditItem
            // 
            btnEditItem.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnEditItem.Location = new Point(999, 94);
            btnEditItem.Name = "btnEditItem";
            btnEditItem.Size = new Size(101, 33);
            btnEditItem.TabIndex = 3;
            btnEditItem.Text = "Edit Item";
            btnEditItem.UseVisualStyleBackColor = true;
            btnEditItem.Click += btnEditItem_Click;
            // 
            // itemsTable
            // 
            itemsTable.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            itemsTable.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            itemsTable.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            itemsTable.Location = new Point(23, 153);
            itemsTable.MultiSelect = false;
            itemsTable.Name = "itemsTable";
            itemsTable.RowHeadersWidth = 62;
            itemsTable.Size = new Size(1077, 420);
            itemsTable.TabIndex = 4;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1126, 594);
            Controls.Add(itemsTable);
            Controls.Add(btnEditItem);
            Controls.Add(btnDelete);
            Controls.Add(btnAddItem);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Inventory";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)itemsTable).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Button btnAddItem;
        private Button btnDelete;
        private Button btnEditItem;
        private DataGridView itemsTable;
    }
}
