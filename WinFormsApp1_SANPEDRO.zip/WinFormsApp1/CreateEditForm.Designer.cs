﻿namespace WinFormsApp1
{
    partial class CreateEditForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelTitle = new Label();
            LabelItem = new Label();
            labelID = new Label();
            lbName = new Label();
            tbName = new TextBox();
            tbCode = new TextBox();
            tbBrand = new TextBox();
            tbUnitPrice = new TextBox();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            btnSave = new Button();
            btnCancel = new Button();
            lbId = new Label();
            btnCancel1 = new Button();
            SuspendLayout();
            // 
            // labelTitle
            // 
            labelTitle.Anchor = AnchorStyles.Top | AnchorStyles.Left | AnchorStyles.Right;
            labelTitle.Font = new Font("Segoe UI", 16F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelTitle.Location = new Point(12, 29);
            labelTitle.Name = "labelTitle";
            labelTitle.Size = new Size(776, 65);
            labelTitle.TabIndex = 0;
            labelTitle.Text = "Create Item";
            labelTitle.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // LabelItem
            // 
            LabelItem.AutoSize = true;
            LabelItem.Location = new Point(58, 94);
            LabelItem.Name = "LabelItem";
            LabelItem.Size = new Size(66, 25);
            LabelItem.TabIndex = 1;
            LabelItem.Text = "ItemID";
            LabelItem.Click += label1_Click;
            // 
            // labelID
            // 
            labelID.AutoSize = true;
            labelID.Location = new Point(139, 94);
            labelID.Name = "labelID";
            labelID.Size = new Size(0, 25);
            labelID.TabIndex = 2;
            // 
            // lbName
            // 
            lbName.AutoSize = true;
            lbName.Location = new Point(58, 138);
            lbName.Name = "lbName";
            lbName.Size = new Size(59, 25);
            lbName.TabIndex = 3;
            lbName.Text = "Name";
            // 
            // tbName
            // 
            tbName.Location = new Point(154, 135);
            tbName.Name = "tbName";
            tbName.Size = new Size(344, 31);
            tbName.TabIndex = 4;
            // 
            // tbCode
            // 
            tbCode.Location = new Point(154, 183);
            tbCode.Name = "tbCode";
            tbCode.Size = new Size(344, 31);
            tbCode.TabIndex = 5;
            // 
            // tbBrand
            // 
            tbBrand.Location = new Point(154, 229);
            tbBrand.Name = "tbBrand";
            tbBrand.Size = new Size(344, 31);
            tbBrand.TabIndex = 6;
            // 
            // tbUnitPrice
            // 
            tbUnitPrice.Location = new Point(154, 277);
            tbUnitPrice.Name = "tbUnitPrice";
            tbUnitPrice.Size = new Size(344, 31);
            tbUnitPrice.TabIndex = 7;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(58, 183);
            label3.Name = "label3";
            label3.Size = new Size(54, 25);
            label3.TabIndex = 8;
            label3.Text = "Code";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(59, 232);
            label4.Name = "label4";
            label4.Size = new Size(58, 25);
            label4.TabIndex = 9;
            label4.Text = "Brand";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(58, 280);
            label5.Name = "label5";
            label5.Size = new Size(81, 25);
            label5.TabIndex = 10;
            label5.Text = "UnitPrice";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(473, 336);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(106, 32);
            btnSave.TabIndex = 11;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnCancel
            // 
            btnCancel.Location = new Point(0, 0);
            btnCancel.Name = "btnCancel";
            btnCancel.Size = new Size(75, 23);
            btnCancel.TabIndex = 16;
            // 
            // lbId
            // 
            lbId.AutoSize = true;
            lbId.Location = new Point(154, 94);
            lbId.Name = "lbId";
            lbId.Size = new Size(59, 25);
            lbId.TabIndex = 13;
            lbId.Text = "label1";
            // 
            // btnCancel1
            // 
            btnCancel1.Location = new Point(587, 336);
            btnCancel1.Name = "btnCancel1";
            btnCancel1.Size = new Size(92, 32);
            btnCancel1.TabIndex = 15;
            btnCancel1.Text = "Cancel";
            btnCancel1.UseVisualStyleBackColor = true;
            btnCancel1.Click += btnCancel1_Click;
            // 
            // CreateEditForm
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnCancel1);
            Controls.Add(lbId);
            Controls.Add(btnCancel);
            Controls.Add(btnSave);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(tbUnitPrice);
            Controls.Add(tbBrand);
            Controls.Add(tbCode);
            Controls.Add(tbName);
            Controls.Add(lbName);
            Controls.Add(labelID);
            Controls.Add(LabelItem);
            Controls.Add(labelTitle);
            Name = "CreateEditForm";
            Text = "Create Item";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelTitle;
        private Label LabelItem;
        private Label labelID;
        private Label lbName;
        private TextBox tbName;
        private TextBox tbCode;
        private TextBox tbBrand;
        private TextBox tbUnitPrice;
        private Label label3;
        private Label label4;
        private Label label5;
        private Button btnSave;
        private Button btnCancel;
        private Label lbId;
        private Button btnCancel1;
    }
}