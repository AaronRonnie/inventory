﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WinFormsApp1.Models;
using WinFormsApp1.Repositories;

namespace WinFormsApp1
{
    public partial class CreateEditForm : Form
    {
        public CreateEditForm()
        {
            InitializeComponent();

            this.DialogResult = DialogResult.Cancel;
        }

        private int itemId = 0;
        public void EditItem(Items item)
        {
            this.Text = "Edit Item";
            this.labelTitle.Text = "Edit Item";
            this.lbId.Text = item.Id.ToString();
            this.tbName.Text = item.Name;
            this.tbCode.Text = item.Code;
            this.tbBrand.Text = item.Brand;
            this.tbUnitPrice.Text = item.UnitPrice.ToString();

            this.itemId = item.Id;

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            Items item = new Items();
            item.Id = this.itemId;
            item.Name = this.tbName.Text;
            item.Code = this.tbCode.Text;
            item.Brand = this.tbBrand.Text;
            item.UnitPrice = decimal.Parse(this.tbUnitPrice.Text);


            var repo = new ItemsRepository();

            if (item.Id == 0)
            {
                repo.CreateItem(item);
            }
            else
            {
                repo.UpdateItem(item);
            }
            this.DialogResult = DialogResult.OK;
        }

        private void btnEditItem_Click(object sender, EventArgs e)
        { }

        private void btnCancel1_Click(object sender, EventArgs e)
        {

        }
    }
}