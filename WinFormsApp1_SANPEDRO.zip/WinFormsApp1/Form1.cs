using System.Data;
using WinFormsApp1.Models;
using WinFormsApp1.Repositories;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            ReadItems();
        }

        private void ReadItems()
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("ID");
            dataTable.Columns.Add("Name");
            dataTable.Columns.Add("Code");
            dataTable.Columns.Add("Brand");
            dataTable.Columns.Add("UnitPrice");
            dataTable.Columns.Add("CreatedAt");

            var repo = new ItemsRepository();
            var items = repo.GetItems();

            foreach (var item in items)
            {
                var row = dataTable.NewRow();
                row["ID"] = item.Id;
                row["Name"] = item.Name;
                row["Code"] = item.Code;
                row["Brand"] = item.Brand;
                row["UnitPrice"] = item.UnitPrice;
                row["CreatedAt"] = item.CreatedAt;
                dataTable.Rows.Add(row);
            }

            this.itemsTable.DataSource = dataTable;

        }
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnAddItem_Click(object sender, EventArgs e)
        {
            CreateEditForm form = new CreateEditForm();
            if (form.ShowDialog() == DialogResult.OK)
            {

                ReadItems();
            }
        }

        private void btnEditItem_Click(object sender, EventArgs e)
        {
            if (itemsTable.SelectedRows.Count == 0) return;
            var val = itemsTable.SelectedRows[0].Cells[0].Value?.ToString();
            if (val == null || val.Length == 0) return;

            int itemId = int.Parse(val);

            var repo = new ItemsRepository();
            Items item = repo.GetItem(itemId);
            if (item == null) return;

            CreateEditForm form = new CreateEditForm();
            form.EditItem(item);

            if (form.ShowDialog() == DialogResult.OK)
            {
                ReadItems();
            }
        }
    }
}
