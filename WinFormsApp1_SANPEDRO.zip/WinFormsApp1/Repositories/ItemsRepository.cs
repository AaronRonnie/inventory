﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Microsoft.Data.SqlClient;


using WinFormsApp1.Models;

namespace WinFormsApp1.Repositories
{
    public class ItemsRepository
    {
        private readonly string connectionString = "Data Source=localhost\\SQLEXPRESS;Integrated Security=True;Connect Timeout=30;Encrypt=True;Trust Server Certificate=True;Application Intent=ReadWrite;Multi Subnet Failover=False";

        public List<Items> GetItems()
        {
            var items = new List<Items>();

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string sql = "SELECT * FROM Items ORDER BY id DESC";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Items item = new Items();
                                item.Id = Convert.ToInt32(reader["id"]);
                                item.Name = reader["name"].ToString();
                                item.Code = reader["code"].ToString();
                                item.Brand = reader["brand"].ToString();
                                item.UnitPrice = Convert.ToDecimal(reader["unitprice"]);
                                item.CreatedAt = Convert.ToDateTime(reader["created_at"]);

                                items.Add(item);
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }

            return items;
        }

        public Items? GetItem(int id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "SELECT * FROM Items WHERE id=@id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);

                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                Items item = new Items();
                                item.Id = Convert.ToInt32(reader["id"]);
                                item.Name = reader["name"].ToString();
                                item.Code = reader["code"].ToString();
                                item.Brand = reader["brand"].ToString();
                                item.UnitPrice = Convert.ToDecimal(reader["unitprice"]);
                                item.CreatedAt = Convert.ToDateTime(reader["created_at"]);
                                return item;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }

            return null;
        }
        public void CreateItem(Items item)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "INSERT INTO Items (name, code, brand, unitprice) " +
                                 "VALUES (@name, @code, @brand, @unitprice);";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@name", item.Name);
                        command.Parameters.AddWithValue("@code", item.Code);
                        command.Parameters.AddWithValue("@brand", item.Brand);
                        command.Parameters.AddWithValue("@unitprice", item.UnitPrice);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }

        public void UpdateItem(Items item)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "UPDATE Items SET name=@name, code=@code, brand=@brand, unitprice=@unitprice WHERE id=@id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@name", item.Name);
                        command.Parameters.AddWithValue("@code", item.Code);
                        command.Parameters.AddWithValue("@brand", item.Brand);
                        command.Parameters.AddWithValue("@unitprice", item.UnitPrice);
                        command.Parameters.AddWithValue("@id", item.Id);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }

        public void DeleteItem(int id)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string sql = "DELETE FROM Items WHERE id=@id";
                    using (SqlCommand command = new SqlCommand(sql, connection))
                    {
                        command.Parameters.AddWithValue("@id", id);
                        command.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Exception: " + ex.ToString());
            }
        }


    }
}
